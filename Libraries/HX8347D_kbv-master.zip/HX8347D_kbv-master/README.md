# HX8347D_kbv
Regular Adafruit_GFX style library

Control Waveshare SPI HX8347D Shield with similar methods to MCUFRIEND_kbv library

Runs on Arduino Uno, Leonardo, Mega2560
